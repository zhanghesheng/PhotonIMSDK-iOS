
#import <Foundation/Foundation.h>

@interface PhotonIMThreadSafeDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>


@end
