
#import <Foundation/Foundation.h>

@interface PhotonIMThreadSafeArray : NSMutableArray

@end
